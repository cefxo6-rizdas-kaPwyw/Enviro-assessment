package com.enviro.assessment.grad001.lutendorathari.repository;

import com.enviro.assessment.grad001.lutendorathari.model.WasteCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WasteCategoryRepository extends JpaRepository<WasteCategory, Long> {
// // JpaRepository already provides CRUD operations like save, findById, delete, etc.
}