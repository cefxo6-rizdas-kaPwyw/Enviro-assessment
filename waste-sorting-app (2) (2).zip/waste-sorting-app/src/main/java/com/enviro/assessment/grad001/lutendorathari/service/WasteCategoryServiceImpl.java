package com.enviro.assessment.grad001.lutendorathari.service;

import com.enviro.assessment.grad001.lutendorathari.exception.ResourceNotFoundException;
import com.enviro.assessment.grad001.lutendorathari.model.WasteCategory;
import com.enviro.assessment.grad001.lutendorathari.repository.WasteCategoryRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WasteCategoryServiceImpl implements WasteCategoryService {

    private final WasteCategoryRepository repository;
    
     // Constructor-based dependency injection for the repository
    public WasteCategoryServiceImpl(WasteCategoryRepository repository) {
        this.repository = repository;
    }

    @Override
    public WasteCategory createWasteCategory(WasteCategory wasteCategory) {
         // Constructor-based dependency injection for the repository
        return repository.save(wasteCategory);
    }

    @Override
    public WasteCategory updateWasteCategory(Long id, WasteCategory wasteCategory) {
         // Fetches an existing category, updates it, and saves the changes
        WasteCategory existing = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("WasteCategory not found"));
        existing.setName(wasteCategory.getName());
        existing.setDescription(wasteCategory.getDescription());
        return repository.save(existing);
    }

    @Override
    public void deleteWasteCategory(Long id) {
        // Deletes a WasteCategory by its ID
        repository.deleteById(id);
    }

    @Override
    public List<WasteCategory> getAllWasteCategories() {
        // Returns a list of all WasteCategories
        return repository.findAll();
    }

    @Override
     // Retrieves a WasteCategory by its ID or throws an exception if not found
    public WasteCategory getWasteCategoryById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("WasteCategory not found"));
    }
}
