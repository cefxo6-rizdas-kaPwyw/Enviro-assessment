package com.enviro.assessment.grad001.lutendorathari.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity

public class WasteCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Auto generates unique IDs 
    private Long id;

    @NotNull(message = "Name cannot be null")//Validates that name is not null
    @Size(min = 2, message = "Name should have at least 2 characters")
    private String name;

    @NotNull(message = "Description cannot be null")//Validates that description is not null
    private String description;

    // Getters and setters for encapsulation and data manipulation
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


}
