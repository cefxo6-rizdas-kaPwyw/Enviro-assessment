package com.enviro.assessment.grad001.lutendorathari.controller;

import com.enviro.assessment.grad001.lutendorathari.model.WasteCategory;
import com.enviro.assessment.grad001.lutendorathari.service.WasteCategoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories") // Base URI for all endpoints
public class WasteCategoryController {

    private final WasteCategoryService wasteCategoryService;

    // Constructor injection for the service
    public WasteCategoryController(WasteCategoryService wasteCategoryService) {
        this.wasteCategoryService = wasteCategoryService;
    }

    // Create a new waste category
    @PostMapping
    public ResponseEntity<WasteCategory> createWasteCategory(@RequestBody WasteCategory wasteCategory) {
        return ResponseEntity.ok(wasteCategoryService.createWasteCategory(wasteCategory));
    }

    // Get all waste categories
    @GetMapping
    public ResponseEntity<List<WasteCategory>> getAllWasteCategories() {
        return ResponseEntity.ok(wasteCategoryService.getAllWasteCategories());
    }

    // Get a specific waste category by ID
    @GetMapping("/{id}")
    public ResponseEntity<WasteCategory> getWasteCategoryById(@PathVariable Long id) {
        return ResponseEntity.ok(wasteCategoryService.getWasteCategoryById(id));
    }

    // Update a waste category by ID
    @PutMapping("/{id}")
    public ResponseEntity<WasteCategory> updateWasteCategory(
            @PathVariable Long id, @RequestBody WasteCategory wasteCategory) {
        return ResponseEntity.ok(wasteCategoryService.updateWasteCategory(id, wasteCategory));
    }

    // Delete a waste category by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWasteCategory(@PathVariable Long id) {
        wasteCategoryService.deleteWasteCategory(id);
        return ResponseEntity.noContent().build();
    }
}
