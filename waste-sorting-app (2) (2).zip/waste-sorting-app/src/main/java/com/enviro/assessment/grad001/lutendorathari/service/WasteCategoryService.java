package com.enviro.assessment.grad001.lutendorathari.service;

import com.enviro.assessment.grad001.lutendorathari.model.WasteCategory;

import java.util.List;

public interface WasteCategoryService {
    WasteCategory createWasteCategory(WasteCategory wasteCategory);
    WasteCategory updateWasteCategory(Long id, WasteCategory wasteCategory);
    void deleteWasteCategory(Long id);
    List<WasteCategory> getAllWasteCategories();
    WasteCategory getWasteCategoryById(Long id);
}